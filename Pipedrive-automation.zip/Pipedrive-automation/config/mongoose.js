const mongoose = require("mongoose");

exports.connect = async () => {
  return mongoose.connect(process.env.DATABASE_URL).catch((err) => console.log("-----mongo-error---", err));
};
