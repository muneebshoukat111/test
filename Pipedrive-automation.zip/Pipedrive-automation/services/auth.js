const { google } = require("googleapis");
const fs = require("fs");
const readline = require("readline");

const credentialsPath = "credentials.json"; // Replace with your credentials.json path
const tokenPath = "token.json"; // Token will be saved here
const SCOPES = ["https://mail.google.com/"]; // Full access to Gmail

// Load OAuth2 credentials from the credentials file
function getOAuth2Client() {
  return new Promise((resolve, reject) => {
    fs.readFile(credentialsPath, (err, content) => {
      if (err) return reject("Error loading client secret file:", err);
      const credentials = JSON.parse(content);
      const { client_secret, client_id, redirect_uris } = credentials.web;

      // Create OAuth2 client
      const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);
      resolve(oAuth2Client);
    });
  });
}

// Generate the OAuth2 URL and get the code for the first time authentication
function getAuthUrl() {
  return getOAuth2Client().then((oAuth2Client) => {
    // Generate the URL for the consent screen
    const authUrl = oAuth2Client.generateAuthUrl({
      access_type: "offline", // To get refresh token
      scope: SCOPES,
    });
    console.log("Authorize this app by visiting this url:");
    console.log(authUrl);
  });
}

// Get tokens from code after user authorizes the app
function getTokensFromCode(code) {
  return getOAuth2Client().then((oAuth2Client) => {
    return oAuth2Client.getToken(code);
  });
}

// Save the token to token.json
function saveToken(token) {
  return new Promise((resolve, reject) => {
    fs.writeFile(tokenPath, JSON.stringify(token), (err) => {
      if (err) reject("Error saving the token:", err);
      else resolve("Token saved to " + tokenPath);
    });
  });
}

// Check if token.json exists, and if so, load the token
function loadToken() {
  return new Promise((resolve, reject) => {
    fs.readFile(tokenPath, (err, content) => {
      if (err) return reject("Error loading token.json:", err);
      resolve(JSON.parse(content));
    });
  });
}

// Refresh the token if it's expired
function refreshAccessToken(oAuth2Client) {
  return loadToken().then((token) => {
    const currentTime = Math.floor(Date.now() / 1000); // Current timestamp in seconds
    if (token.expiry_date <= currentTime) {
      console.log("Access token has expired, refreshing...");
      return oAuth2Client.refreshAccessToken();
    }
    return token;
  });
}

// Main function to authenticate, send emails, and refresh tokens
async function authenticate() {
  try {
    // Check if token.json exists
    let token;
    if (fs.existsSync(tokenPath)) {
      // Load existing token
      token = await loadToken();
      const oAuth2Client = await getOAuth2Client();
      oAuth2Client.setCredentials(token);

      // Refresh token if expired
      const refreshedToken = await refreshAccessToken(oAuth2Client);
      oAuth2Client.setCredentials(refreshedToken);
      console.log("Successfully authenticated and token refreshed if necessary.");
      return oAuth2Client; // Return the authenticated oAuth2Client
    } else {
      // Token does not exist, get authorization code from user
      console.log("Token not found. Please authenticate by visiting the following URL:");
      await getAuthUrl();

      // Read the code entered by the user
      const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
      });

      rl.question("Enter the authorization code: ", async (code) => {
        try {
          const oAuth2Client = await getOAuth2Client();
          const { tokens } = await getTokensFromCode(code);
          oAuth2Client.setCredentials(tokens);

          // Save the new token to token.json
          await saveToken(tokens);
          console.log("Authentication successful and token saved.");
          rl.close();
          return oAuth2Client;
        } catch (err) {
          console.error("Error while getting the tokens:", err);
          rl.close();
        }
      });
    }
  } catch (err) {
    console.error("Error during authentication:", err);
  }
}

// Example of how to use the authenticated client
authenticate()
  .then((oAuth2Client) => {
    // Now you can use oAuth2Client to send emails
    console.log("Ready to send emails!");
  })
  .catch(console.error);
