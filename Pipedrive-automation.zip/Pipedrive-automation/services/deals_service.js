const pipedrive = require("pipedrive");
const { sendEmail, checkForReplies, generateGPTTemplate, getThreadByMessageID } = require("./mail_service");
const deal_model = require("../models/deal_model");
const stage_model = require("../models/stage_model");
const follow_up_model = require("../models/follow_up_model");
const defaultClient = new pipedrive.ApiClient();
let apiToken = defaultClient.authentications.api_key;
apiToken.apiKey = process.env.PIPEDRIVE_API_KEY;

exports.updateDealStatus = async () => {
  try {
    const apiInstance = new pipedrive.StagesApi(defaultClient);
    const stages = await stage_model.find({ is_active: true });
    for (let stage of stages) {
      const response = await apiInstance.getStageDeals(stage.stage_id);
      try {
        if (response.data) {
          for (let deal of response.data) {
            // check if rotten time passed
            if (deal.label === "98") {
              try {
                if (new Date(deal.rotten_time) <= new Date(Date.now())) {
                  const updateDealApi = new pipedrive.DealsApi(defaultClient);
                  let dealMessages = await updateDealApi.getDealMailMessages(deal.id);
                  if (!dealMessages) {
                    console.log("This Deal has no linked emails");
                    continue;
                  }
                  dealMessages = dealMessages.data;
                  const lastMessage = dealMessages[0];
                  const firstMessage = dealMessages[dealMessages.length - 1];

                  const messageId = firstMessage.data.mua_message_id;
                  let { threadId, subject } = await getThreadByMessageID(messageId);
                  let dealDetails = await updateDealApi.getDeal(deal.id);
                  dealDetails = dealDetails.data;

                  const isDealExist = await deal_model.findOne({
                    dealId: deal.id,
                  });

                  //check if deal already exists in database
                  if (isDealExist) {
                    if (isDealExist.status == "lost") return;
                    if (!lastMessage.data.from.some((item) => item.email_address === dealDetails.person_id.email[0].value)) {
                      console.log("REPLY not recieved");
                      const follow_up_number = isDealExist.follow_up_number + 1;
                      const followUpTemplate = await follow_up_model.findOne({ number: follow_up_number, stage: stage._id });
                      if (followUpTemplate.type == "lost") {
                        await updateDealApi.updateDeal(isDealExist.dealId, {
                          status: "lost",
                          lost_reason: "not responsive",
                        });
                        await deal_model.findOneAndUpdate(
                          {
                            dealId: dealDetails.id,
                          },
                          {
                            follow_up_number,
                            updated_at: new Date(dealDetails.update_time),
                            status: "lost",
                          }
                        );
                      } else if (followUpTemplate.type == "gpt") {
                        console.log("GPT");
                        const threadId = await sendEmail(
                          follow_up_number,
                          stage._id,
                          dealDetails.person_name,
                          subject,
                          dealDetails.person_id.email[0].value,
                          messageId,
                          "gpt",
                          followUpTemplate.content,
                          isDealExist.threadId
                        );
                        await updateDealApi.updateDeal(isDealExist.dealId, {
                          update_time: new Date(Date.now()),
                        });

                        await deal_model.findOneAndUpdate(
                          {
                            dealId: dealDetails.id,
                          },
                          {
                            follow_up_number,
                            updated_at: new Date(dealDetails.update_time),
                            threadId,
                          }
                        );
                      } else {
                        if (isDealExist.follow_up_number < stage.follow_ups) {
                          threadId = await sendEmail(follow_up_number, stage._id, dealDetails.person_name, subject, dealDetails.person_id.email[0].value, messageId, "template");
                          // Reset Rotten Time of deal
                          await updateDealApi.updateDeal(isDealExist.dealId, {
                            update_time: new Date(Date.now()),
                          });

                          await deal_model.findOneAndUpdate(
                            {
                              dealId: dealDetails.id,
                            },
                            {
                              follow_up_number,
                              updated_at: new Date(dealDetails.update_time),
                              threadId,
                            }
                          );
                        }
                      }
                    } else {
                      await deal_model.findOneAndUpdate(
                        {
                          dealId: dealDetails.id,
                        },
                        {
                          follow_up_number: 0,
                          stage: stage._id,
                          updated_at: new Date(dealDetails.update_time),
                        }
                      );
                    }
                  } else {
                    const follow_up_number = 1;
                    const response = await updateDealApi.updateDeal(deal.id, {
                      update_time: new Date(Date.now()),
                    });
                    const followUpTemplate = await follow_up_model.findOne({ number: follow_up_number, stage: stage._id });
                    if (followUpTemplate.type == "gpt") {
                      console.log("GPT");

                      const newDeal = new deal_model({
                        dealId: dealDetails.id,
                        title: dealDetails.title,
                        status: dealDetails.status,
                        pipelineId: dealDetails.pipeline_id,
                        stage: stage._id,
                        updated_at: new Date(dealDetails.update_time),
                        created_at: new Date(dealDetails.add_time),
                        rotten_time: new Date(response.data.rotten_time),
                        email: dealDetails.person_id.email[0].value,
                        follow_up_number,
                      });
                      threadId = await sendEmail(
                        follow_up_number,
                        stage._id,
                        dealDetails.person_name,
                        subject,
                        dealDetails.person_id.email[0].value,
                        messageId,
                        "gpt",
                        followUpTemplate.content,
                        threadId
                      );
                      newDeal.threadId = threadId;
                      await newDeal.save();
                    } else {
                      const newDeal = new deal_model({
                        dealId: dealDetails.id,
                        title: dealDetails.title,
                        status: dealDetails.status,
                        pipelineId: dealDetails.pipeline_id,
                        stage: stage._id,
                        updated_at: new Date(dealDetails.update_time),
                        created_at: new Date(dealDetails.add_time),
                        rotten_time: new Date(response.data.rotten_time),
                        email: dealDetails.person_id.email[0].value,
                        follow_up_number,
                      });
                      threadId = await sendEmail(follow_up_number, stage._id, dealDetails.person_name, subject, dealDetails.person_id.email[0].value, messageId);

                      newDeal.threadId = threadId;
                      await newDeal.save();
                    }
                  }
                }
              } catch (error) {
                console.log(error);
                continue;
              }
            }
          }
        }

        return response.data;
      } catch (error) {
        console.log(error);
        continue;
      }
    }
  } catch (error) {
    console.log(error);
    throw error;
  }
};

exports.createTemplate = async () => {
  try {
    const footer = `<div><img src="https://lh7-us.googleusercontent.com/docsz/AD_4nXcI97wKCmGu_KSONBI_i36c6mmZCfqnkHqdK-6IOPnM1aNoppUkMcDGtHd8WEPxlBmzpXrGkrW2VkGcCyaQW2S1mns-p0MrHJpz0eSx9mDaMLlOeznFI5srgyKmBWydF2GWaBJSOu3A2AFR6RYcsNRWQNM?key=r5p_8jNyoZBAPNG-HWdV0w" style="max-width: 100%; height: 50px;"/><p style="font-size: 12px; color: #777; line-height: 1.4;">This email, including any attachments, is confidential and may be legally privileged. If you received it by mistake, please be aware of its status. Notify us immediately and delete this message from your system. Do not copy, use, or disclose its contents to anyone else, as doing so could violate confidentiality.</p></div>`;
    const template1 = `<body style="font-family: Arial, sans-serif; color: #333; padding: 20px; background-color: #ffffff;">
    <div style="background-color: #ffffff; padding-top:20px;">
    <p style="font-size: 16px; line-height: 1.6;">Hey <span style="font-weight: bold;">{{firstName}}</span>,How are you?</p>
    <p style="font-size: 16px; line-height: 1.6;">I’ve got your free 5-day campaign here and ready to go, but I didn’t hear back.</p>
    <p style="font-size: 16px; line-height: 1.6;">Do you still want us to go ahead with it?</p>
    <p style="font-size: 16px; line-height: 1.6;">No strings, it’s totally free – just need you to confirm.</p>

    
    ${footer}
    </div>
    </body>`;

    const template2 = `<body style="font-family: Arial, sans-serif; color: #333; padding: 20px; background-color: #ffffff;">
                        <div style="background-color: #ffffff; padding-top:20px;">
                        <p style="font-size: 16px; line-height: 1.6; font-weight: bold;">{{firstName}}</p>
                        <p style="font-size: 16px; line-height: 1.6;">Wanna see the playlist placements we set up for you?</p>
                        
                        ${footer}
                        </div>
                        </body>
                        `;
    const template3 = `<body style="font-family: Arial, sans-serif; color: #333; padding: 20px; background-color: #ffffff;">
                        <div style="background-color: #ffffff; padding-top:20px;">
                        <p style="font-size: 16px; line-height: 1.6; " >Hey <span style="font-weight: bold;">{{firstName}},</span> just checking in to see if you were still interested in a free trial with us.</p>
        ${footer}
        </div>
        </body>
    `;
    const template4 = `<body style="font-family: Arial, sans-serif; color: #333; padding: 20px; background-color: #ffffff;">
    <div style="background-color: #ffffff; padding-top:20px; ">
    <p style="font-size: 16px; line-height: 1.6;">How did your demo campaign go?</p>
    <p style="font-size: 16px; line-height: 1.6;">Looks good from our end but obviously we can’t see as much as you.</p>
    <p style="font-size: 16px; line-height: 1.6;">I’d love to show you what it looks like to have us working on a bigger campaign for you.</p>
    <p style="font-size: 16px; line-height: 1.6;">This quick video shows you what to do now your campaign has ended - <a href="https://fast.wistia.com/embed/medias/qwunyvha3e" >LINK TO VIDEO</a>.</p>
    <p style="font-size: 16px; line-height: 1.6;">I’d love to chat about working on something bigger. Sound good?</p>
    
    
    ${footer}
    </div>
    </body>`;
    const template5 = `<body style="font-family: Arial, sans-serif; color: #333; padding: 20px; background-color: #ffffff;">
    <div style="background-color: #ffffff;padding-top:20px; ">
    <p style="font-size: 16px; line-height: 1.6;">Okay now I’m worried, were your results okay?</p>
    <p style="font-size: 16px; line-height: 1.6;">I usually hear back before now and when I don’t it makes me worry that something bad happened.</p>
    <p style="font-size: 16px; line-height: 1.6;">Let me know things are okay when you get a moment just so I know we’re not having any issues at our end.</p>    
    
    ${footer}
    </div>
    </body>`;
    const template6 = `<body style="font-family: Arial, sans-serif; color: #333; padding: 20px; background-color: #ffffff;">
    <div style="background-color: #ffffff; padding-top:20px; ">
    <p style="font-size: 16px; line-height: 1.6;">Hey  - we paid for your demo with us but I haven’t heard back.</p>
    <p style="font-size: 16px; line-height: 1.6;">Did everything go okay? Was there a problem?</p>
    <p style="font-size: 16px; line-height: 1.6;">Let me know either way!</p>
    <p style="font-size: 16px; line-height: 1.6;">Also check out this quick video about the campaign ending - <a href="https://fast.wistia.com/embed/medias/qwunyvha3e" >LINK TO VIDEO</a>.</p>
    
    
    ${footer}
    </div>
    </body>`;

    const template7 = `<body style="font-family: Arial, sans-serif; color: #333; padding: 20px; background-color: #ffffff;">
    <div style="background-color: #ffffff; padding-top:20px; ">
    <img src="https://pipedrive-files-cmh-1-pipedrive-com.s3.us-east-2.amazonaws.com/company/13362618/user/20898195/files/ce7066ba-2eb8-47eb-b5c0-3265a76108d5.gif?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAQ7LXCX4L3NTW6Z6E%2F20241206%2Fus-east-2%2Fs3%2Faws4_request&X-Amz-Date=20241206T122002Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&response-content-disposition=inline%3B%20filename%3Dkevin.gif&response-content-type=image%2Fgif&x-id=GetObject&X-Amz-Signature=91c2eb9a672b966e511c6452e9537b0877619ca81b3beb9efb52f888a943be9b"/>    
    
    ${footer}
    </div>
    </body>`;

    const template8 = `<body style="font-family: Arial, sans-serif; color: #333; padding: 20px; background-color: #ffffff;">
    <div style="background-color: #ffffff; padding-top:20px; ">
    <p style="font-size: 16px; line-height: 1.6;">Hey , are you still interested in a full pitching campaign?</p>
    <p style="font-size: 16px; line-height: 1.6;">Attached is our <a href="https://drive.google.com/file/d/1OBPEm9NewsrxsDMRIt9nB7ZSNeT6dUxx/view" >pricing and info pdf</a>  for you to check out, and <a href="https://fast.wistia.com/embed/medias/qwunyvha3e" >a video that explains how everything works.</a> </p>
   
    
    ${footer}
    </div>
    </body>`;

    const template9 = `<body style="font-family: Arial, sans-serif; color: #333; padding: 20px; background-color: #ffffff;">
    <div style="background-color: #ffffff; padding-top:20px; ">
    <p style="font-size: 16px; line-height: 1.6;">Hey, sorry for all of the emails. I never heard back from you, so I'm just assuming promoting your music might not be your top priority right now.</p>
    <p style="font-size: 16px; line-height: 1.6;">No worries, if you change your mind, here's our <a href="https://drive.google.com/file/d/1OBPEm9NewsrxsDMRIt9nB7ZSNeT6dUxx/view" >pricing and info pdf</a> and <a href="https://fast.wistia.com/embed/medias/qwunyvha3e" >a video that explains how everything works.</a> again for you to check out. </p>
    <p style="font-size: 16px; line-height: 1.6;">Is there a better time for us to reconnect about your marketing plans?</p>
    
    ${footer}
    </div>
    </body>`;
    const template10 = `<body style="font-family: Arial, sans-serif; color: #333; padding: 20px; background-color: #ffffff;">
    <div style="background-color: #ffffff; padding-top:20px; ">
    <img src="https://pipedrive-files-cmh-1-pipedrive-com.s3.us-east-2.amazonaws.com/company/13362618/user/20898195/files/b0da264d-4a22-428b-b61d-b137cf876819.gif?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAQ7LXCX4L3NTW6Z6E%2F20241206%2Fus-east-2%2Fs3%2Faws4_request&X-Amz-Date=20241206T122124Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&response-content-disposition=inline%3B%20filename%3Dsponge.gif&response-content-type=image%2Fgif&x-id=GetObject&X-Amz-Signature=b937c0181d3aeda902787a7d78fa1f72ce4ade0b38713e5f140df07ba4c7f914"/>
    
    ${footer}
    </div>
    </body>`;

    const templates = [
      {
        number: 1,
        template_name: "Inbound Ask Follow-up #1",
        stage: "6752951ae64922b8eb5e9536",
        type: "template",
        content: template1,
      },
      {
        number: 2,
        template_name: "Inbound Ask Follow-up #2",
        stage: "6752951ae64922b8eb5e9536",
        type: "template",
        content: template2,
      },
      {
        number: 3,
        template_name: "Last Call for Free Trial",
        stage: "6752951ae64922b8eb5e9536",
        type: "template",
        content: template3,
      },
      {
        number: 4,
        template_name: null,
        stage: "6752951ae64922b8eb5e9536",
        type: "lost",
        content: null,
      },
      {
        number: 1,
        template_name: "Trial Ended Follow-up #1",
        stage: "67529601c0a910d5aeb87b68",
        type: "template",
        content: template4,
      },
      {
        number: 2,
        template_name: "Trial Ended Follow-up #2",
        stage: "67529601c0a910d5aeb87b68",
        type: "template",
        content: template5,
      },
      {
        number: 3,
        template_name: "Trial Ended Follow-up #3",
        stage: "67529601c0a910d5aeb87b68",
        type: "template",
        content: template6,
      },
      {
        number: 4,
        template_name: "GPT 1",
        stage: "67529601c0a910d5aeb87b68",
        type: "gpt",
        content: null,
      },
      {
        number: 5,
        template_name: null,
        stage: "67529601c0a910d5aeb87b68",
        type: "lost",
        content: null,
      },
      {
        number: 1,
        template_name: "Sales follow up chatgpt 1",
        stage: "67529641c0a910d5aeb87b69",
        type: "gpt",
        content: null,
      },
      {
        number: 2,
        template_name: "Sales follow up chatgpt 2",
        stage: "67529641c0a910d5aeb87b69",
        type: "gpt",
        content: null,
      },
      {
        number: 3,
        template_name: "Sales - Follow Up - Kevin",
        stage: "67529641c0a910d5aeb87b69",
        type: "template",
        content: template7,
      },
      {
        number: 4,
        template_name: "Sales follow up 2",
        stage: "67529641c0a910d5aeb87b69",
        type: "template",
        content: template8,
      },
      {
        number: 5,
        template_name: "Sales follow up 3",
        stage: "67529641c0a910d5aeb87b69",
        type: "template",
        content: template9,
      },
      {
        number: 6,
        template_name: "Sales - Follow Up - Sponge",
        stage: "67529641c0a910d5aeb87b69",
        type: "template",
        content: template10,
      },
      {
        number: 7,
        template_name: null,
        stage: "67529641c0a910d5aeb87b69",
        type: "lost",
        content: null,
      },
    ];
    const re = await follow_up_model.insertMany(templates);
    console.log("result", re);
  } catch (error) {
    throw error;
  }
};
