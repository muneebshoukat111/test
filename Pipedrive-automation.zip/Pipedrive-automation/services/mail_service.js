const { google } = require("googleapis");
const fs = require("fs");
const axios = require("axios");
const base64url = require("base64url");
const follow_up_model = require("../models/follow_up_model");

const tokenPath = "token.json";
const credentialsPath = "credentials.json";

async function loadOAuth2Client() {
  const content = fs.readFileSync(credentialsPath);
  const credentials = JSON.parse(content);
  const { client_id, client_secret, redirect_uris } = credentials.web;

  const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);

  // Check if there's a saved token
  const token = fs.existsSync(tokenPath) ? JSON.parse(fs.readFileSync(tokenPath)) : null;

  if (token) {
    // Set credentials from the saved token
    oAuth2Client.setCredentials(token);
    const currentTime = Date.now();
    const expiryTime = token.expiry_date || 0;
    if (currentTime >= expiryTime - 300000) {
      console.log("REFRESH TOKEN");
      const { credentials: refreshedCredentials } = await oAuth2Client.refreshAccessToken();
      oAuth2Client.setCredentials(refreshedCredentials);

      fs.writeFileSync(tokenPath, JSON.stringify(oAuth2Client.credentials));
    }
  }

  return oAuth2Client;
}
exports.sendEmail = async (follow_up_number, stage_id, firstName, subject, to, messageId, followUpTemplateType = "template", prompt = null, threadId = null) => {
  try {
    const oAuth2Client = await loadOAuth2Client();

    const gmail = google.gmail({ version: "v1", auth: oAuth2Client });
    if (followUpTemplateType === "gpt") {
      let emailContext = "";
      if (threadId) {
        emailContext = await this.getThreadHistory(threadId);
      }
      body = await this.generateGPTTemplate(prompt + emailContext);
    } else {
      body = await this.getTemplateContent(follow_up_number, stage_id, firstName);
    }

    const rawMessage = [
      `To: ${to}`,
      `Subject: ${subject}`,
      `In-Reply-To: ${messageId}`,
      `References: ${messageId}`,
      'Content-Type: text/html; charset="UTF-8"',
      "Content-Transfer-Encoding: 7bit",
      "",
      body,
    ].join("\n");
    const encodedMessage = Buffer.from(rawMessage).toString("base64").replace(/\+/g, "-").replace(/\//g, "_");
    const res = await gmail.users.messages.send({
      userId: "me",
      requestBody: {
        raw: encodedMessage,
      },
    });
    threadId = res.data.threadId; // Capture threadId
    console.log("Email sent with threadId:", threadId);
    return threadId;
  } catch (error) {
    console.error("Error sending email:", error);
    throw error;
  }
};
exports.getThreadHistory = async (threadId = "") => {
  try {
    const oAuth2Client = await loadOAuth2Client();

    const gmail = google.gmail({ version: "v1", auth: oAuth2Client });
    let context = "Context: \n";
    const threadDetails = await gmail.users.threads.get({
      userId: "me", // Use 'me' for the authenticated user
      id: threadId, // The threadId you're interested in
    });

    threadDetails.data.messages.map((item) => {
      if (item.labelIds.includes("SENT")) {
        let decodedBody = "";
        if (item.payload.body?.data) {
          decodedBody = base64url.decode(item.payload.body.data);
        } else if (item.payload.parts && item.payload.parts.length > 0 && item.payload.parts[0].body?.data) {
          decodedBody = base64url.decode(item.payload.parts[0].body.data);
        }
        context += `\nme: ${decodedBody.split("On")[0]}`;
      } else {
        let decodedBody = "";
        if (item.payload.parts && item.payload.parts.length > 0 && item.payload.parts[0].body?.data) {
          decodedBody = base64url.decode(item.payload.parts[0].body.data);
        }

        context += `\ncustomer: ${decodedBody.split("On")[0]}`;
      }
    });
    return context;
  } catch (error) {
    console.log(error);
  }
};
exports.checkForReplies = async (threadId = "1939686e66ca4178") => {
  try {
    const oAuth2Client = await loadOAuth2Client();

    const gmail = google.gmail({ version: "v1", auth: oAuth2Client });

    const threadDetails = await gmail.users.threads.get({
      userId: "me", // Use 'me' for the authenticated user
      id: threadId, // The threadId you're interested in
    });
    console.log(threadDetails.data.messages);
    const lastMessage = threadDetails?.data?.messages?.pop() || null;
    if (lastMessage) {
      console.log(lastMessage.payload.headers[0]);
      if (lastMessage.payload.headers.find((item) => item.name === "Delivered-To")) {
        console.log("Reply Recieved");
        return true;
      } else {
        console.log("Reply not recieved");
        return false;
      }
    }
  } catch (error) {}
};

exports.getTemplateContent = async (follow_up_number, stage_id, firstName) => {
  try {
    const template = await follow_up_model.findOne({
      number: follow_up_number,
      stage: stage_id,
    });
    if (!template) {
      throw new Error("Template not found");
    }

    let content = template.content || null;

    // Replace placeholders with dynamic values

    const placeholder = `{{firstName}}`;
    if (content) content = content.replace(new RegExp(placeholder, "g"), firstName); // Replace all instances
    return content;
  } catch (error) {
    console.error("Error fetching or processing template:", error);
    throw error;
  }
};
exports.generateGPTTemplate = async (prompt) => {
  try {
    console.log(prompt);
    const GPT_API_URL = "https://api.openai.com/v1/chat/completions";
    const response = await axios.post(
      GPT_API_URL,
      {
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.GPT_KEY}`,
        },
      }
    );
    return response.data.choices[0].message.content.trim();
  } catch (error) {
    console.error("Error generating GPT template:", error.response?.data || error.message);
    throw error;
  }
};

exports.getThreadByMessageID = async (id) => {
  try {
    const oAuth2Client = await loadOAuth2Client();

    const gmail = google.gmail({ version: "v1", auth: oAuth2Client });
    const res = await gmail.users.messages.list({
      userId: "me", // 'me' refers to the authenticated user's email address
      q: `rfc822msgid:${id}`,
    });
    const threads = res.data.messages.pop();

    const threadDetail = await gmail.users.threads.get({
      userId: "me", // Use 'me' for the authenticated user
      id: threads.threadId, // The threadId you're interested in
    });

    const subject = threadDetail.data.messages[0].payload.headers.find((item) => item.name === "Subject");
    return {
      threadId: threads.threadId,
      subject: subject.value,
    };
  } catch (error) {
    console.log(error);
  }
};
