require("dotenv").config();
const express = require("express");
const cron = require("node-cron");

const app = express();
const mongoose = require("./config/mongoose");
const { updateDealStatus } = require("./services/deals_service");

mongoose.connect();
app.use(express.json());
const PORT = 3000;

cron.schedule("0 10-16 * * *", async () => {
  console.log("Cron starts");
  await updateDealStatus();
});
app.get("/", (req, res) => {
  // res.send("Server is Up");
});
app.listen(PORT, () => {
  console.log(`Listening on port ${PORT}`);
});
