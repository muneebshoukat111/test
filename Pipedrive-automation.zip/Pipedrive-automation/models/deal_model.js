const mongoose = require("mongoose");

const newSchema = mongoose.Schema(
  {
    dealId: {
      type: Number,
      unique: true,
    },
    title: {
      type: String,
    },
    status: {
      type: String,
    },
    pipelineId: {
      type: Number,
    },
    stage: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Stages",
    },
    updated_at: {
      type: Date,
      default: new Date(Date.now()),
    },
    created_at: {
      type: Date,
      default: new Date(Date.now()),
    },
    rotten_time: {
      type: Date,
    },
    email: {
      type: String,
    },
    follow_up_number: {
      type: Number,
    },
    threadId: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);
module.exports = mongoose.model("Deal", newSchema);
