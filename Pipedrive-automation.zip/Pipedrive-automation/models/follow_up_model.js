const mongoose = require("mongoose");

const newSchema = new mongoose.Schema(
  {
    number: {
      type: Number,
    },
    template_name: {
      type: String,
    },
    stage: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Stages",
    },
    type: {
      type: String,
    },
    content: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("FollowUps", newSchema);
