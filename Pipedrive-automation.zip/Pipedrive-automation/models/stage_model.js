const mongoose = require("mongoose");

const newSchema = new mongoose.Schema(
  {
    name: {
      type: String,
    },
    stage_id: {
      type: Number,
      unique: true,
    },
    follow_ups: {
      type: Number,
      default: 0,
    },
    is_active: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Stages", newSchema);
